<?php
session_start();
header("Content-Type: text/html;charset=utf-8");


//一、導入
	require("../dbconfig.php");
	require("../functions.php");

//二、MySQL，


//三、action
	switch($_GET["action"]){
		
		case "del": //削除
			//SQL実行
			$sql = "delete from tb_order where id={$_GET['id']}";
			mysql_query($sql);
			
			//遷移
			header("Location:orderList.php");
			break;
			
			
		case "update": //変更
			//1. 情報get
			$id 			= trim($_POST['id']);
			$orderMoney 	= trim($_POST["order_money"]);
			$consignee 		= trim($_POST["consignee"]);
			$address 		= trim($_POST["address"]);
			$phone 			= trim($_POST["phone"]);
			$updatetime 	= date('y-m-d H:i:s');
			//2. 検証
			if(empty($orderMoney)){
				die(errorTip("オーダー金額を入力してください", "editOrder.php?id={$id}"));
			}
			
			if(empty($consignee)){
				die(errorTip("受取人を入力してください", "editOrder.php?id={$id}"));
			}
			
			if(empty($address)){
				die(errorTip("お届け先を入力してください", "editOrder.php?id={$id}"));
			}
			
			if(empty($phone)){
				die(errorTip("電話番号を入力してください", "editOrder.php?id={$id}"));
			}
			
			
			//3. 変更実行
			$sql = "update tb_order set order_money='{$orderMoney}', consignee='{$consignee}', address='{$address}', phone='{$phone}', updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
			
			//6. 結果判断
			if(mysql_affected_rows()>0){
				echo "変更成功";
			}else{
				echo "変更失败".mysql_error();
			}
			echo "<br/> <a href='orderList.php'>リストに戻る<a>";
			
			break;

	}

//四、
mysql_close();


