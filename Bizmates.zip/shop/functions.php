<?php 
//関数

/**
  * 関数処理
  * @param string filename 
  * @param string $path	
  * @param array  アップロードできるファイル種類
  * @return array ["error"] false:失败，true:成功
  *  			　["info"] ファイル置き場
  */
function uploadFile($filename,$path,$typelist=null){
	//1. アップロードファイル名get
	$upfile = $_FILES[$filename];
	if(empty($typelist)){
		$typelist=array("image/gif","image/jpg","image/jpeg","image/png");//アップロードできるファイル種類
	}
	//$path="upload3"; //path
	$res=array("error"=>false);//結果
	//error
	if($upfile["error"]>0){
		switch($upfile["error"]){
			case 1: 
				$res["info"]="エラー";
				break;
			case 2:
				$res["info"]="エラー";
				break;
			case 3:
				$res["info"]="エラー";
				break;
			case 4:
				$res["info"]="エラー";
				break;
			case 6:
				$res["info"]="エラー";
				break;
			case 7:
				$res["info"]="エラー";
				break;
			default:
				$res["info"]="エラー";
				break;
		}
		return $res;
	}

	//3.大きさ
	if($upfile["size"]>2000000){
		$res["info"]="アップロードされたファイルが大きすぎです！";
		return $res;
	}

	//4.種類
	if(!in_array($upfile["type"],$typelist)){
		$res["info"]="アップロードのタイプが一致しません！".$upfile["type"];
		return $res;
	}

	//5. 名前を生成する(ランダム)
	$fileinfo = pathinfo($upfile["name"]);
	do{
		$newfile = date("YmdHis").rand(1000,9999).".".$fileinfo["extension"];//ファイル名を生成する(ランダム)
	}while(file_exists($newfile));
	//6. アップロード実行
	if(is_uploaded_file($upfile["tmp_name"])){
		if(move_uploaded_file($upfile["tmp_name"],$path."/".$newfile)){
			//return
			$res["info"]=$newfile;
			$res["error"]=true;
			return $res;
		}else{
			$res["info"]="アップロード失败！";
		}
	}else{
		$res["info"]="アップロードできません！";
	}
	return $res;
}

//========================================================================================

/**
 * 等比缩放函数（以保存的方式实现）
 * @param string $picname 被缩放的处理图片源
 * @param int $maxx 缩放后图片的最大宽度
 * @param int $maxy 缩放后图片的最大高度
 * @param string $pre 缩放后图片名的前缀名
 * @return String 返回后的图片名称(带路径)，如a.jpg=>s_a.jpg
 */
function imageUpdateSize($picname,$maxx=100,$maxy=100,$pre="s_"){
	$info = getimageSize($picname); //获取图片的基本信息
	
	$w = $info[0];//長さ
	$h = $info[1];//高さ
	
	//写真種類get	
	switch($info[2]){
		case 1: //gif
			$im = imagecreatefromgif($picname);
			break;
		case 2: //jpg
			$im = imagecreatefromjpeg($picname);
			break;
		case 3: //png
			$im = imagecreatefrompng($picname);
			break;
		default:
			die("写真のタイプ間違います！");
	}
	
	//サイズ調整
	if(($maxx/$w)>($maxy/$h)){
		$b = $maxy/$h;
	}else{
		$b = $maxx/$w;
	}
	
	//サイズ計算
	$nw = floor($w*$b);
	$nh = floor($h*$b);
	
	//新規
	$nim = imagecreatetruecolor($nw,$nh);
		
	//サイズ調整
	imagecopyresampled($nim,$im,0,0,0,0,$nw,$nh,$w,$h);
	
	//画像プリントアウト
	$picinfo = pathinfo($picname);//path
	$newpicname= $picinfo["dirname"]."/".$pre.$picinfo["basename"];
	switch($info[2]){
		case 1:
			imagegif($nim,$newpicname);
			break;
		case 2:
			imagejpeg($nim,$newpicname);
			break;
		case 3:
			imagepng($nim,$newpicname);
			break;
	}
	
	imagedestroy($im);
	imagedestroy($nim);
	
	return $newpicname;
}

//========================================================================================

/**
 * 为一张图片添加上一个logo图片水印（以保存的方式实现）
 * @param string $picname 被处理图片源
 * @param string $logo 水印图片
 * @param string $pre 处理后图片名的前缀名
 * @return String 返回后的图片名称(带路径)，如a.jpg=>n_a.jpg
 */
function imageUpdateLogo($picname,$logo,$pre="n_"){
	$picnameinfo = getimageSize($picname); //写真get	
	$logoinfo = getimageSize($logo); //logo写真get
	//var_dump($logoinfo);
	//根据图片类型创建出对应的图片源
	switch($picnameinfo[2]){
		case 1: //gif
			$im = imagecreatefromgif($picname);
			break;
		case 2: //jpg
			$im = imagecreatefromjpeg($picname);
			break;
		case 3: //png
			$im = imagecreatefrompng($picname);
			break;
		default:
			die("写真のタイプ間違います");
	}
	//根据logo图片类型创建出对应的图片源
	switch($logoinfo[2]){
		case 1: //gif
			$logoim = imagecreatefromgif($logo);
			break;
		case 2: //jpg
			$logoim = imagecreatefromjpeg($logo);
			break;
		case 3: //png
			$logoim = imagecreatefrompng($logo);
			break;
		default:
			die("写真のタイプ間違います");
	}
	

	//执行图片水印处理
	imagecopyresampled($im,$logoim,$picnameinfo[0]-$logoinfo[0],$picnameinfo[1]-$logoinfo[1],0,0,$logoinfo[0],$logoinfo[1],$logoinfo[0],$logoinfo[1]);
	
	//画像プリントアウト
	$picinfo = pathinfo($picname);
	$newpicname= $picinfo["dirname"]."/".$pre.$picinfo["basename"];
	switch($picnameinfo[2]){
		case 1:
			imagegif($im,$newpicname);
			break;
		case 2:
			imagejpeg($im,$newpicname);
			break;
		case 3:
			imagepng($im,$newpicname);
			break;
	}
	
	imagedestroy($im);
	imagedestroy($logoim);
	
	return $newpicname;
}
/**
 * error
 * @param unknown $msg
 * @param unknown $backUrl
 * @return string
 */
function errorTip($msg, $backUrl){
	return "<div style='text-align:center;margin-top:100px;font-size:18px;'>【{$msg}】"."<a href='{$backUrl}'>点击返回</a></div>";
}

function  alertMes($mes, $url) {
	echo "<script>alert('{$mes}');</script>";
	echo "<script>window.location='{$url}';</script>";
}

/**
 * 管理者登録確認
 */
function checkLogined() {
	if((!isset($_SESSION['adminId']) || $_SESSION['adminId'] == "")) {
		alertMes("ログインしてください。", "login.php");
	}
}
/**
 * ユーザー登録確認
 */
function checkUserLogined() {
	if((!isset($_SESSION['userId']) || $_SESSION['userId'] == "")) {
		alertMes("ログインしてください", "login.php");
	}
}