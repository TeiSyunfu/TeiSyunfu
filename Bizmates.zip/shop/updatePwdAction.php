<?php
header("Content-Type: text/html;charset=utf-8");

session_start();
//一、導入
	require("dbconfig.php");
	require("functions.php");

//二、action
	
	switch($_GET["action"]){
		case "updatePwd": //パスワード変更
			//1. 情報get
			$userId			= $_SESSION['userId'];
			$password 		= $_POST['password'];
			$repassword 	= $_POST['repassword'];
			$newpassword 	= $_POST['newpassword'];
			$updatetime 	= date('y-m-d H:i:s');
			
			//2. 検証
			if(empty($password)){
				alertMes('古いパスワードは空です', 'updatePwd.php');
			}
			if(empty($repassword)){
				alertMes('確認用パスワードは空です', 'updatePwd.php');
			}
			if(empty($newpassword)){
				alertMes('新しいパスワードは空です', 'updatePwd.php');
			}
			if($repassword != $newpassword){
				alertMes('パスワードは合致ではありません', 'updatePwd.php');
			}
			// ユーザー存在判断
			$sql_count = "select * from user where id = {$userId}";
			$result = mysql_query($sql_count);
			
			
			if($result && mysql_num_rows($result)>0){
				$item = mysql_fetch_assoc($result);
				if($item['password']== md5(trim($password))){
					if(trim($repassword) == trim($newpassword)){
						$md5Pwd = md5(trim($newpassword));
						$sql = "update user set password='{$md5Pwd}',updatetime='{$updatetime}' where id={$userId}";
						//echo $sql;
						mysql_query($sql);
						//変更結果判断
						if(mysql_affected_rows()>0){
							alertMes("パスワードを変更しました", "index.php");
						}else{
							echo "パスワードの変更失败".mysql_error();
						}
					}else{
						alertMes("一致ではありません", "updatePwd.php");
					}
				}else{
					alertMes("古いパスワード間違いました", "updatePwd.php");
				}
			}else{
				alertMes('ユーザー存在しません', 'index.php');
			}

			
			break;
		
			
			

	}

//三、
mysql_close();


