<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>商品情報管理</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
		<script type="text/javascript" src="../script/check.js"></script>
	</head>
	<body>
			<?php  
				//1.導入 
					require("../dbconfig.php");
				//2. SQL
				
				//3. 商品情報取得
					$sql = "select * from goods where id={$_GET['id']}";
					$result = mysql_query($sql);
				
				//4. 判断
					if($result && mysql_num_rows($result)>0){
						$shop = mysql_fetch_assoc($result); 
					}else{
						die("商品情報が見つかりません");
					}
			
			
			
			?>
			<h3 class="page_title">商品情報変更</h3>
			<form action="goodsAction.php?action=update" enctype="multipart/form-data" method="post" onsubmit="return validate_form(this)">
				<input type="hidden" name="id" value="<?php echo $shop['id']; ?>"/>
				<input type="hidden" name="oldpic" value="<?php echo $shop['pic']; ?>"/>
			<table border="0" width="1200" class="frm_table">
				<tr>
					<td align="right">商品名：</td>
					<td><input type="text" name="name" value="<?php echo $shop['name']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">タイプ：</td>
					<td>
						<select name="typeid">
						<?php 
							require("../dbconfig.php");
							foreach($typelist as $k=>$v){
								$sd = ($shop['typeid']==$k)?"selected":"";//type判断
								echo "<option value='{$k}' {$sd}>{$v}</option>";
							}
						?>
						</select>
					</td>
				</tr>
				<tr>
					<td align="right">価格：</td>
					<td><input type="text" name="price"  value="<?php echo $shop['price']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">在庫：</td>
					<td><input type="text" name="total"  value="<?php echo $shop['total']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">写真：</td>
					<td><input type="file" name="pic"/></td>
				</tr>
				<tr>
					<td align="right" valign="top">商品情報：</td>
					<td><textarea rows="10" cols="70" name="note"><?php echo $shop['note']; ?></textarea></td>
				</tr>
				<tr>
					
					<td colspan="2" align="center">
						<input type="submit" value="変更"/>&nbsp;&nbsp;&nbsp;
						<input type="reset" value="リセット"/>
					</td>
				</tr>
				<tr>
					<td align="right" valign="top">&nbsp;</td>
					<td><img src="../uploads/<?php echo $shop['pic']; ?>" style="max-width: 200px;"/></td>
				</tr>
			</table>
			</form>
		<script type="text/javascript">
		function validate_form(thisform){
			with (thisform){
				if (validate_required(name,"商品名を入力してください")==false){
					name.focus();
			      	return false;
			  }
				if (validate_required(price,"価格を入力してください")==false){
					price.focus();
			      	return false;
			  }

				if (validate_required(total,"在庫を入力してください")==false){
					total.focus();
			      	return false;
			  }
				if (validate_required(note,"商品情報を入力してください")==false){
					note.focus();
			      	return false;
			  }
			}
		}
    </script>
	</body>
</html>