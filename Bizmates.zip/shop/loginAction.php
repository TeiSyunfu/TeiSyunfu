<?php
header("Content-Type: text/html;charset=utf-8");
session_start();
//導入
	require("dbconfig.php");
	require("functions.php");


//二、action
	
	switch($_GET["act"]){
		case "login": //登録
			//1. 情報get
			$username 		= trim($_POST["username"]);
			$password 		= trim($_POST["password"]);
			$md5Pwd 		= md5($password);
			//2. 確認
			if(empty($username)){
				alertMes('ユーザー名は空にはできません', 'login.php');
			}
			if(empty($password)){
				alertMes('パスワードは空にはできません', 'login.php');
			}
			
			
			// ユーザー存在判断
			$sql_count = "select * from user where username = '{$username}' and password='{$md5Pwd}'";
			$result = mysql_query($sql_count);
			
			
			if($result && mysql_num_rows($result)>0){
				$item = mysql_fetch_assoc($result);
				if($username == 'admin'){
					$_SESSION['adminName'] = $item['username'];
					$_SESSION['adminId'] = $item['id'];
					$_SESSION['userName'] = $item['username'];
					$_SESSION['userId'] = $item['id'];
					alertMes('ログイン成功', 'index.php');
				}else{
					$_SESSION['userName'] = $item['username'];
					$_SESSION['userId'] = $item['id'];
					alertMes('ログイン成功', 'index.php');
				}
			}else{
				alertMes('ログイン失败，やり直す', 'login.php');
			}

			
			break;
		
		case "logout": 
			//delete　id　get
			$_SESSION['adminName'] = '';
			$_SESSION['adminId'] = '';
			$_SESSION['userName'] = '';
			$_SESSION['userId'] = '';
			
			//遷移
			header("Location:index.php");
			break;
			
			

	}

//四
mysql_close();


