<?php
session_start();
header("Content-Type: text/html;charset=utf-8");


//一、導入
	require("dbconfig.php");
	require("functions.php");


//三、action
	switch($_GET["action"]){
		case "add": //添加
			//1. 追加情報get
			$userId 		= $_SESSION['userId'];
			$goodsId 		= trim($_POST["goods_id"]);// 商品id
			$orderSn		= date('Ymd') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);//オーダー番号
			$consignee		= trim($_POST['consignee']);// 受取人
			$phone			= trim($_POST['phone']);// 電話番号
			$address		= trim($_POST['address']);// お届け先
			$orderMoney 	= 0;// オーダー金額
			// オーダー金額検索
			$sql = "select * from goods where id={$goodsId}";
			$result = mysql_query($sql);
			if($result && mysql_num_rows($result)>0){
				$goods = mysql_fetch_assoc($result);//変更べき情報出力
				$orderMoney = $goods['price'];
			}else{
				alertMes('商品は見つかりませんでした', 'index.php');
			}
			if($orderMoney <= 0){
				alertMes('订单金额需要大于0', 'index.php');
			}
			
			$createtime 	= date('y-m-d H:i:s');// 注文時間
			
			//2. 検証
			if(empty($phone)){
				alertMes('電話番号', 'addOrder.php?id='.$goodsId);
			}
			if(empty($consignee)){
				alertMes('受取人', 'addOrder.php?id='.$goodsId);
			}
			if(empty($address)){
				alertMes('配送先', 'addOrder.php?id='.$goodsId);
			}
			
			
			
			//3. sql
			$sql = "insert into tb_order(user_id,goods_id,order_sn,order_money,consignee,phone,address,createtime) values('{$userId}','{$goodsId}','{$orderSn}','{$orderMoney}','{$consignee}','{$phone}','{$address}','{$createtime}')";
			//echo $sql;
			mysql_query($sql);
			
			//4. 結果出力
			if(mysql_insert_id()>0){
				alertMes('注文完了', 'myOrderList.php');
			}else{
				echo "注文失败！".mysql_error();
			}
			
			
			break;
		
		case "del": //delete
			$userId 		= $_SESSION['userId'];
			//SQL
			$sql = "delete from tb_order where id={$_GET['id']} and user_id={$userId}";;
			mysql_query($sql);
			
			//遷移
			header("Location:myOrderList.php");
			break;
			
			
		case "update": //変更
			//1. 変更情報get
			$id 			= trim($_POST['id']);
			$orderMoney 	= trim($_POST["order_money"]);
			$consignee 		= trim($_POST["consignee"]);
			$address 		= trim($_POST["address"]);
			$phone 			= trim($_POST["phone"]);
			$updatetime 	= date('y-m-d H:i:s');
			//2. データ検証
			if(empty($orderMoney)){
				alertMes("金額を入力してください", "editOrder.php?id={$id}");
			}
			
			if(empty($consignee)){
				alertMes("受取人を入力してください", "editOrder.php?id={$id}");
			}
			
			if(empty($address)){
				alertMes("配送先を入力してください", "editOrder.php?id={$id}");
			}
			
			if(empty($phone)){
				alertMes("電話番号を入力してください", "editOrder.php?id={$id}");
			}
			
			
			//3. 変更実行
			$sql = "update tb_order set order_money='{$orderMoney}', consignee='{$consignee}', address='{$address}', phone='{$phone}', updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
			
			//6. 変更結果判断
			if(mysql_affected_rows()>0){
				alertMes("変更成功", "myOrderList.php");
			}else{
				//echo "変更失败".mysql_error();
				alertMes("変更失败", "myOrderList.php");
			}
			
			break;

	}

//四
mysql_close();


