<?php
header("Content-Type: text/html;charset=utf-8");


//一、導入
	require("dbconfig.php");
	require("functions.php");


//二、action
	switch($_GET["action"]){
		case "add": //追加
			//1. 追加情報get
			$username 		= trim($_POST["username"]);
			$password 		= trim($_POST["password"]);
			$repassword 	= trim($_POST["repassword"]);
			$createtime 	= date('y-m-d H:i:s');
			$md5Pwd 		= md5($password);
			//2. 検証
			if(empty($username)){
				alertMes('IDは空です', 'register.php');
			}
			if(empty($password)){
				alertMes('パスワードは空です', 'register.php');
			}
			if($password != $repassword){
				alertMes('パスワードは合致ではありません', 'register.php');
			}
			
			// ユーザー複数判断
			$sql_count = "select count(*) as total from user where username = '{$username}'";
			$result = mysql_query($sql_count);
			if($result){
				$res = mysql_fetch_array($result);
				$num=$res['total'];
				if($num > 0){
					alertMes('IDは既に存在しています', 'register.php');
				}
			}
			
			
			//3. SQL
			$sql = "insert into user(username, password,createtime)  values('{$username}','{$md5Pwd}','{$createtime}')";
			echo $sql;
			mysql_query($sql);
			
			//4. 結果出力
			if(mysql_insert_id()>0){
				alertMes('新規登録成功', 'login.php');
			}else{
				alertMes('新規登録失败！', 'register.php');
			}
			
			
			break;
		
		

	}

//四、
mysql_close();


