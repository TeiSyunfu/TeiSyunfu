<?php 
session_start();// 开启session
require("functions.php");// 引入函数
checkLogined();// 判断管理员是否登录
?>
<!doctype html>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>后台管理</title>
		<link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
	</head>
	<body>
		<div class="admin_head">
			<h3>管理システム</h3>
		</div>
		<div class="admin_content">
			<!--左侧列表-->
        	<div class="menu">
        		<div class="cont">
        			<div class="title">管理者</div>
        			<ul class="mList">
        				<li>
	                        <h3><span>+</span>ユーザー管理</h3>
	                        <dl>
	                        	<dd><a href="admin_user/addUser.php" target="mainFrame">ユーザー添加</a></dd>
	                            <dd><a href="admin_user/userList.php" target="mainFrame">ユーザーリスト</a></dd>
	                        </dl>
                    	</li>
        				<li>
	                        <h3><span>+</span>商品管理</h3>
	                        <dl>
	                        	<dd><a href="admin_goods/addGoods.php" target="mainFrame">商品添加</a></dd>
	                            <dd><a href="admin_goods/goodsList.php" target="mainFrame">商品リスト</a></dd>
	                        </dl>
                    	</li>
                    	<li>
	                        <h3><span>+</span>オーダー管理</h3>
	                        <dl>
	                            <dd><a href="admin_order/orderList.php" target="mainFrame">オーダーリスト</a></dd>
	                        </dl>
                    	</li>
                    	<li>
	                        <h3><span>+</span>システム管理</h3>
	                        <dl>
	                            <dd><a href="index.php">ホームページへ</a></dd>
	                        </dl>
	                        <dl>
	                            <dd><a href="loginAction.php?act=logout">ログアウト</a></dd>
	                        </dl>
                    	</li>
        			</ul>
        		</div>
        	</div>
		
			<div class="main">
	            <!--右側内容-->
	            <div class="cont">
	                <!-- <div class="title">システム管理</div> -->
	                <iframe src="adminMain.php"  frameborder="0" name="mainFrame" width="100%" height="2000"></iframe>   
	            </div>
        	</div>
        	
		</div>
			
		
	</body>
</html>