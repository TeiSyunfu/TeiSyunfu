<!doctype html>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>ユーザー情報管理</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
	</head>
	<body>
		
			<h3>ユーザー情報リスト</h3>
			<div class="admin_search_bar">
				<form action="<?php echo $_SERVER['PHP_SELF'];?>">
					<ul>
						<li><label>ユーザー名</label><input type="text" class="txt" name="keyword" value="<?php if(isset($_GET['keyword'])) echo $_GET['keyword'];?>"></li>
						<li><button>検索</button></li>
					</ul>
				</form>
			</div>
			<table border="1" width="1000" class="frm_table">
				<tr>
					<th>ユーザー番号</th>
					<th>ユーザー名</th>
					<th>アクセス時間</th>
					<th>操作</th>
				</tr>
				<?php
				
				
				//情報　データベース　→　リスト
				//1.導入
					require("../dbconfig.php");
					
					// 当ページ
					if(!isset($_GET["page"])){
						$page=1;
					}else{
						$page=$_GET["page"];
					}
					
					// 
					$temp=($page-1)*$list_num;
					
					// キーワード検索
					if(!isset($_GET['keyword'])){
						$keyword = "";
					}else{
						$keyword = trim($_GET['keyword']);
					}
					
					
				//2. データベー
					
					$sql_count = "select count(*) as total from user where 1";
					if($keyword){
						$sql_count.= " and username like '%{$keyword}%'";
					}
					$result = mysql_query($sql_count);
					$res = mysql_fetch_array($result);
					$num=$res['total'];
					$p_count=ceil($num/$list_num);					//总页数为总条数除以每页显示数
				
				//3. 検索実行
					$sql = "select * from user where 1 ";
					if($keyword){
						$sql .=  " and username like '%{$keyword}%'";
					}
					$sql .= " limit {$temp},{$list_num}";
					$result = mysql_query($sql);
					
					
					
					
				//4. 結果出力
					while($row = mysql_fetch_assoc($result)){
						echo "<tr>";
						echo "<td>{$row['id']}</td>";
						echo "<td>{$row['username']}</td>";
						echo "<td>{$row['createtime']}</td>";
						if($row['username'] != "admin"){
							echo "<td class='txt_center'>
							<a href='userAction.php?action=del&id={$row['id']}' class='op_btn'>削除</a>
							<a href='editUser.php?id={$row['id']}' class='op_btn'>変更</a>
							<a href='resetUserPwd.php?id={$row['id']}' class='op_btn'>リセット</a>
							</td>";
						}else{
							echo "<td class='txt_center'>
							<a class='op_btn' onclick='cantDel();'>削除</a>
							<a href='editUser.php?id={$row['id']}' class='op_btn'>変更</a>
							<a href='resetUserPwd.php?id={$row['id']}' class='op_btn'>リセット</a>
							</td>";
						}
						
						echo "</tr>";
					}
					
				
				
				//5. close
		
				
				?>
			</table>
			<?php 
			// 分页
			if($num > 0){
				$prev_page=$page-1;						
				$next_page=$page+1;						
				//echo "next_page=".$next_page.",p_count=".$p_count;
				echo "<p align=\"center\"> ";
				if ($page<=1)								
				{
					echo "1 | ";
				}
				else										
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=1&keyword={$keyword}'>1</a> | ";
				}
				if ($prev_page<1)							
				{
					echo "戻る | ";
				}
				else										
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$prev_page&keyword={$keyword}'>戻る</a> | ";
				}
				if ($next_page>$p_count)						
				{
					echo "次 | ";
				}
				else										
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$next_page&keyword={$keyword}' class='underline'>次</a> | ";
				}
				if ($page>=$p_count)						
				{
					echo "ラスト</p>\n";
				}
				else										
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$p_count&keyword={$keyword}'>ラスト</a></p>\n";
				}
			}else{
				echo "<P align='center'>記録ありません</p>";
			}
			?>
			<script>
				function cantDel(){
					alert("管理者は削除できません");
				}
			</script>
	</body>
</html>