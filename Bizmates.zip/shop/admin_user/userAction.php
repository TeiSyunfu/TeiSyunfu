<?php
header("Content-Type: text/html;charset=utf-8");


//一、導入
	require("../dbconfig.php");
	require("../functions.php");

//二、MySQL


//三、action
	switch($_GET["action"]){
		case "add": //追加
			//1. 情報get
			$username 		= trim($_POST["username"]);
			$password 		= trim($_POST["password"]);
			$repassword 	= trim($_POST["repassword"]);
			$createtime 	= date('y-m-d H:i:s');
			$md5Pwd 		= md5($password);// パスワード
			//2. 検索
			if(empty($username)){
				die(errorTip("ユーザー名を入力してください", "addUser.php"));
			}
			if(empty($password)){
				die(errorTip("パスワードを入力してください", "addUser.php"));
			}
			if($password != $repassword){
				die(errorTip("パスワードが一致ではありません", "addUser.php"));
			}
			
			//ユーザー複数存在判断
			$sql_count = "select count(*) as total from user where username = '{$username}'";
			$result = mysql_query($sql_count);
			if($result){
				$res = mysql_fetch_array($result);
				$num=$res['total'];
				if($num > 0){
					die(errorTip("このユーザー名が使用しています", "addUser.php"));
				}
			}
			
			
			//3. SQL
			$sql = "insert into user values(null,'{$username}','{$md5Pwd}','{$createtime}',null)";
			//echo $sql;
			mysql_query($sql);
			
			//4. 結果判断
			if(mysql_insert_id()>0){
				echo "追加成功！";
			}else{
				echo "追加失败！".mysql_error();
			}
			echo "<br/> <a href='userList.php'>リストに戻る<a>";
			
			
			break;
		
		case "del": //削除
			//get 実行
			$sql = "delete from user where id={$_GET['id']}";
			mysql_query($sql);
			
			//遷移
			header("Location:userList.php");
			break;
			
			
		case "update": //変更
			//1. 情報get
			$username 		= trim($_POST["username"]);
			$id 			= trim($_POST['id']);
			$updatetime 	= date('y-m-d H:i:s');
			//2. 検索
			if(empty($username)){
				die(errorTip("ユーザー名を入力してください", "editUser.php?id={$id}"));
			}
			
			
			// ユーザー名複数存在判断
			$sql_count = "select count(*) as total from user where username = '{$username}' and id !={$id}";
			$result = mysql_query($sql_count);
			if($result){
				$res = mysql_fetch_array($result);
				$num=$res['total'];
				if($num > 0){
					die(errorTip("このユーザー名が使用しています", "editUser.php?id={$id}"));
				}
			}
			
			//5. 変更実行
			$sql = "update user set username='{$username}',updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
			
			//6. 判断
			if(mysql_affected_rows()>0){
				echo "変更成功";
			}else{
				echo "変更失败".mysql_error();
			}
			echo "<br/> <a href='userList.php'>リストに戻る<a>";
			
			break;
		case "resetPwd":
			$id 			= trim($_POST['id']);
			$updatetime 	= date('y-m-d H:i:s');
			$password 		= trim($_POST["password"]);
			$repassword 	= trim($_POST["repassword"]);
			$createtime 	= date('y-m-d H:i:s');
			$md5Pwd 		= md5($password);// パスワード
			//1. 検証
			if(empty($password)){
				die(errorTip("パスワードを入力してください", "resetUserPwd.php?id={$id}"));
			}
			if($password != $repassword){
				die(errorTip("パスワードが一致ではありません", "resetUserPwd.php?id={$id}"));
			}
			//2. 変更実行
			$sql = "update user set password='{$md5Pwd}',updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
				
			//3. 結果判断
			if(mysql_affected_rows()>0){
				echo "パスワードリセット成功";
			}else{
				echo "パスワードリセット失败".mysql_error();
			}
			echo "<br/> <a href='userList.php'>リストに戻る<a>";
			break;

	}

//四
mysql_close();


