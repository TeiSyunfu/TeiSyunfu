<?php 
	session_start();
?>
<div class="shop_header">
    	<h1 class="shop_title">Fruits Wrold</h1>
    	<div class="search_bar">
    		<form action="<?php echo $_SERVER['PHP_SELF'];?>">
    			<input type="text" name="searchword" autocomplete="off" value="<?php if(isset($_GET['searchword'])) echo $_GET['searchword'];?>"><button>搜索</button>
    		</form>
    	</div>
    	<div class="login_register_bar">
    		<?php 
    			if(isset($_SESSION) && isset($_SESSION['userId']) && $_SESSION['userId']){
    		?>
    		<?php 
    				if($_SESSION['adminId']){
    		?>
    		<a href="admin.php">管理システム</a>
    		|
    		<a href="loginAction.php?act=logout">ログアウト</a>
    		<?php 
    				}else{
    		?>
    		<a href="myOrderList.php">注文内容</a>
    		|
    		<a href="loginAction.php?act=logout">ログアウト</a>
    		<?php 
    				}
    		?>
    		<?php ?>
    			
    		<?php 
    			}else{
    		?>
    			<a href="login.php">login</a>
    			|
    			<a href="register.php">始めて</a>
    		<?php 
    			}
    		?>
    		
    		
    	</div>
    </div>
    <div class="shop_nav">
    	<ul>
    		<li><a href="index.php">ホームへ</a></li>
    		<li><a href="myOrderList.php">注文内容</a></li>
    		<?php 
    			if(isset($_SESSION) && isset($_SESSION['userId']) && $_SESSION['userId']){
    		?>
    		<li><a href="updatePwd.php">パスワード変更</a></li>
    		<?php 
    			}
    		?>
    	</ul>
    </div>