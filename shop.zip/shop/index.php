<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>shop</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>

<body class="shop_body">
</head>
    <?php 
    	// top
		include 'front-top.php';
	?>
    <div class="shop_contain">
    	<ul class="overflow_hidden">
    	<?php 
	    	//DBから情報を読み取って出力する
	    	//1
	    	require_once "dbconfig.php" ;
	    		
	    	// 現在のページ
	    	if(!isset($_GET["page"])){
	    		$page=1;
	    	}else{
	    		$page=$_GET["page"];
	    	}
	    		
	    	// 何行目から始める
	    	$temp=($page-1)*$front_list_num;
	    		
	    	// キーワード
	    	if(!isset($_GET['searchword'])){
	    		$searchword = "";
	    	}else{
	    		$searchword = trim($_GET['searchword']);
	    	}
	    		
	    		
	    	//2. DB
	    	$sql_count = "select count(*) as total from goods where 1";
	    	if($searchword){
	    		$sql_count.= " and name like '%{$searchword}%'";
	    	}
	    	$result = mysql_query($sql_count);
	    	if($result){
	    		$res = mysql_fetch_array($result);
	    		$num=$res['total'];
	    	}else{
	    		$num = 0;
	    	}
	    	
	    	$p_count=ceil($num/$front_list_num);					//ページ数
	    	
	    	//3. 执行商品信息查询
	    	$sql = "select * from goods where 1 ";
	    	if($searchword){
	    		$sql .=  " and name like '%{$searchword}%'";
	    	}
	    	$sql .= " limit {$temp},{$front_list_num}";
	    	$result = mysql_query($sql);
	    	//4. 解析商品信息（解析结果集）
	    	while($result && $row = mysql_fetch_assoc($result)){
    	?>
    		<li>
    			<div class="goods_item">
    				<a href="goodsDetail.php?id=<?php echo $row['id'];?>"><img src="uploads/<?php echo $row['pic'];?>" class="goods_img"></a>
    				<div class="goods_price">￥<?php echo $row['price'];?></div>
    				<div class="goods_name"><?php echo $row['name'];?></div>
    			</div>
    		</li>
    	<?php 
	    	}
    	?>
    	
    	</ul>
    	<div class="page_contain">
    		<?php 
			// page
			if($num > 0){
				$prev_page=$page-1;						//‐1
				$next_page=$page+1;						//+1
				//echo "next_page=".$next_page.",p_count=".$p_count;
				echo "<p align=\"center\"> ";
				if ($page<=1)								//如果当前页小于等于1只有显示
				{
					echo "Page1 | ";
				}
				else										//如果当前页大于1显示指向第一页的连接
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=1&searchword={$searchword}'>Page1</a> | ";
				}
				if ($prev_page<1)							//如果上一页小于1只显示文字
				{
					echo "戻る | ";
				}
				else										//如果大于1显示指向上一页的连接
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$prev_page&searchword={$searchword}'>戻る</a> | ";
				}
				if ($next_page>$p_count)						//如果下一页大于总页数只显示文字
				{
					echo "次 | ";
				}
				else										//如果小于总页数则显示指向下一页的连接
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$next_page&searchword={$searchword}' class='underline'>次</a> | ";
				}
				if ($page>=$p_count)						//如果当前页大于或者等于总页数只显示文字
				{
					echo "最後</p>\n";
				}
				else										//如果当前页小于总页数显示最后页的连接
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$p_count&searchword={$searchword}'>最後</a></p>\n";
				}
			}else{
				echo "<P align='center'>&#128557</p>";
			}
			?>
    	</div>
    </div>
    <div class="shop_footer">
    	<?php echo COPYRIGHT;?>
    </div>
</body>

</html>