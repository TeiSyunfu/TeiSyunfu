<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <title>パスワードの変更</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
    <script type="text/javascript" src="script/check.js"></script>
</head>

<body class="shop_body">
	<?php 
		include 'front-top.php';
		include 'functions.php';
		checkUserLogined();// 判断用户是否登录
	?>
    <div class="formContain">
    	<form action="updatePwdAction.php?action=updatePwd" method="post" onsubmit="return validate_form(this)">
    		<h2 class="frm_title">パスワード変更</h2>
    		<p><span>古いパスワード</span><input type="password" name="password" class="txt-inp"></p>
    		<p><span>新しいパスワード</span><input type="password" name="newpassword" class="txt-inp"></p>
    		<p><span>パスワードを確認する</span><input type="password" name="repassword" class="txt-inp"></p>
    		<p class="txt_center"><input type="submit" value="変更" class="frm-btn"></p>
    	</form>
    </div>
    <script type="text/javascript">
    function validate_form(thisform){
    	with (thisform){
	      if (validate_required(password,"古いパスワードを入力してください")==false){
	    	  	password.focus();
		      	return false;
		  }
	      if (validate_required(newpassword,"新しいパスワードを入力してください")==false){
	    	  	 newpassword.focus();
	    		 return false;
	     }
	      if (validate_required(repassword,"パスワードを確認してください")==false){
	    	     repassword.focus();
	    		 return false;
	     }
		     if(validate_equal(newpassword, repassword, "パスワードは合致ではありません") == false){
		    	 repassword.focus();
	    		 return false;
			 }
	  }
    }
    </script>
</body>

</html>