<?php
header("Content-Type: text/html;charset=utf-8");


//一、導入
	require("../dbconfig.php");
	require("../functions.php");

//二、MySQL，


//三、action取得する
	switch($_GET["action"]){
		case "add": //添加
			//1. 追加情報取得
			$name 	= $_POST["name"];
			$typeid = $_POST["typeid"];
			$price 	= $_POST["price"];
			$total 	= $_POST["total"];
			$note 	= $_POST["note"];
			$addtime = time();
			//2. 検証
			if(empty($name)){
				die(errorTip("商品名を入力してください", "addGoods.php?id={$id}"));
			}
			//3. 写真アップロード
			$upinfo = uploadFile("pic","../uploads/");
			if($upinfo["error"]===false){
				die(errorTip("アップロード失败：".$upinfo["info"], "addGoods.php?id={$id}"));
			}else{
				//成功
				$pic = $upinfo[info];// 写真名取得
			}
			//4. 执行图片缩放
			imageUpdateSize('../uploads/'.$pic,50,50);
			
			//5. SQL実行
			$sql = "insert into goods values(null,'{$name}','{$typeid}',{$price},{$total},'{$pic}','{$note}',{$addtime},null)";
			//echo $sql;
			mysql_query($sql);
			
			//6. 結果判断
			if(mysql_insert_id()>0){
				echo "商品発表成功！";
			}else{
				echo "商品発表失败！".mysql_error();
			}
			echo "<br/> <a href='goodsList.php'>商品リストに戻る<a>";
			
			
			break;
		
		case "del": //
			//ID取得して実行
			$sql = "delete from goods where id={$_GET['id']}";
			mysql_query($sql);
			//delete実行
			if(mysql_affected_rows()>0){
				@unlink("../uploads/".$_GET['picname']);
				@unlink("../uploads/s_".$_GET['picname']);
			}
			//goodsList.phpに遷移
			header("Location:goodsList.php");
			break;
			
			
		case "update": //変更
			//1. 変更情報を取得
			$name 	= $_POST["name"];
			$typeid = $_POST["typeid"];
			$price 	= $_POST["price"];
			$total 	= $_POST["total"];
			$note 	= $_POST["note"];
			$id = $_POST['id'];
			$pic = $_POST['oldpic'];
			$updatetime 	= date('y-m-d H:i:s');
			//2. 検証
			if(empty($name)){
				die(errorTip("商品名を入力してください", "editGoods.php?id={$id}"));
			}
			
			//3. 写真アップロード判断
			if($_FILES['pic']['error']!=4){
				//アップロード実行
				$upinfo = uploadFile("pic","../uploads/");
				if($upinfo["error"]===false){
					die(errorTip("写真アップロード失败：".$upinfo["info"], "editGoods.php?id={$id}"));
				}else{
					//アップロード成功
					$pic = $upinfo[info];// 写真名取得
					//4. 有图片上传，执行缩放
					imageUpdateSize('../uploads/'.$pic,50,50);
				}
			
			}
			
			//5. 変更実行
			$sql = "update goods set name='{$name}',typeid={$typeid},price={$price},total={$total},note='{$note}',pic='{$pic}',updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
			
			//6. 判断
			if(mysql_affected_rows()>0){
				//新しい写真アップロードしたら古いやつdelete
				if($_FILES['pic']['error']!=4){
					@unlink("../uploads/".$_POST['oldpic']);
					@unlink("../uploads/s_".$_POST['oldpic']);
				}
				echo "変更成功";
			}else{
				echo "変更失败".mysql_error();
			}
			echo "<br/> <a href='goodsList.php'>商品リストに戻る<a>";
			
			break;

	}

//四、关闭数据库
mysql_close();


