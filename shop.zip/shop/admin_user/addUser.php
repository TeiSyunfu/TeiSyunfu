<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>ユーザー情報管理</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
		<script type="text/javascript" src="../script/check.js"></script>
	</head>
	<body>
			<h3 class="page_title">ユーザー情報変更</h3>
			<form action="userAction.php?action=add" enctype="multipart/form-data" method="post" onsubmit="return validate_form(this)">
			<table border="0" width="900" class="frm_table">
				<tr>
					<td align="right">ユーザー名：</td>
					<td><input type="text" name="username" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">パスワード：</td>
					<td><input type="password" name="password" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">パスワード確認：</td>
					<td><input type="password" name="repassword" class="frm_txt"/></td>
				</tr>
				
				<tr>
					
					<td colspan="2" align="center">
						<input type="submit" value="追加"/>&nbsp;&nbsp;&nbsp;
						<input type="reset" value="リセット"/>
					</td>
				</tr>
			</table>
			</form>
	<script type="text/javascript">
		function validate_form(thisform){
			with (thisform){
				if (validate_required(username,"ユーザー名を入力してください")==false){
					username.focus();
			      	return false;
			  }
				if (validate_required(password,"パスワードを入力してください")==false){
					password.focus();
			      	return false;
			  }

				if (validate_required(repassword,"もう一度パスワードを入力してください")==false){
					repassword.focus();
			      	return false;
			  }
			}
		}
    </script>
	</body>
</html>