<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <title>新規</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
    <script type="text/javascript" src="script/check.js"></script>
</head>

<body class="shop_body">
	<?php 
		include 'front-top.php';
	?>
    <div class="formContain">
    	<form action="registerAction.php?action=add" method="post" onsubmit="return validate_form(this)">
    		<h2 class="frm_title">新規登録</h2>
    		<p><span>IDを入力してください</span><input type="text" name="username" autocomplete="off" class="txt-inp"></p>
    		<p><span>パスワードを入力してください</span><input type="password" name="password" class="txt-inp"></p>
    		<p><span>パスワードをを確認します</span><input type="password" name="repassword" class="txt-inp"></p>
    		<p class="txt_center"><input type="submit" value="新規登録" class="frm-btn"></p>
    	</form>
    </div>
    <script type="text/javascript">
    function validate_form(thisform){
    	with (thisform){
	      if (validate_required(username,"IDを入力してください")==false){
		      	username.focus();
		      	return false;
		  }
	      if (validate_required(password,"パスワードを入力してください")==false){
	    		 password.focus();
	    		 return false;
	     }
	      if (validate_required(repassword,"パスワードをを確認してください")==false){
	    	  repassword.focus();
	    		 return false;
	     }
		     if(validate_equal(password, repassword, "パスワードは合致ではありません") == false){
		    	 repassword.focus();
	    		 return false;
			 }
	  }
    }
    </script>
</body>

</html>